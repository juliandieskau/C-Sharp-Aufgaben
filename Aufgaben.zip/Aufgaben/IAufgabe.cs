﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgaben
{
    public interface IAufgabe
    {
        /// <summary>
        /// Programmablauf einer Aufgabe
        /// </summary>
        void run();
    }
}
